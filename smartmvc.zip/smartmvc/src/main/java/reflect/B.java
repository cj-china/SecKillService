package reflect;

public class B {
  public void f1() {
    System.out.println("B的f1方法");
  }

  public void testF2() {
    System.out.println("B的testF2方法");
  }

  public void testFoo() {
    System.out.println("B的testFoo方法");
  }

}
